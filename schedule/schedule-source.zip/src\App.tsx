import { useState } from "react";
import { SessionCard } from "./components/SessionCard";
import { scheduleData, ScheduleEvent } from "./data/schedule";

// Grouping utility
const groupEvents = (events: ScheduleEvent[]) => {
  const byDay: Record<string, Record<string, ScheduleEvent[]>> = {};

  events.forEach((event) => {
    if (!byDay[event.day_label]) {
      byDay[event.day_label] = {};
    }
    if (!byDay[event.day_label][event.time_slot]) {
      byDay[event.day_label][event.time_slot] = [];
    }
    byDay[event.day_label][event.time_slot].push(event);
  });

  return byDay;
};

export default function App() {
  const groupedData = groupEvents(scheduleData);
  const days = Object.keys(groupedData);
  const [activeDay, setActiveDay] = useState(days[0]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold">Вейновские чтения</h1>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Day Tabs */}
        <div className="flex gap-2 mb-8 border-b border-gray-200">
          {days.map((day) => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`px-6 py-3 rounded-none text-sm font-bold uppercase tracking-wider transition-all duration-200 border-b-4 ${
                activeDay === day
                  ? 'border-yellow-400 text-black bg-yellow-50'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Events */}
        <div className="space-y-16">
          {Object.entries(groupedData[activeDay] || {}).map(([timeSlot, events]) => (
            <div key={timeSlot}>
              <h2 className="text-xl font-bold mb-4">{timeSlot}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {events.map((event) => (
                  <SessionCard key={event.cell_id} data={event} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
